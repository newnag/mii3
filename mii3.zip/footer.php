<footer><p>&copy;Develop by Miimoi Team Version 2.0</p></footer>

<script src="<?php bloginfo('template_url')?>/js/javascript.js"></script>
<?php wp_footer();?>
</body>
</html>