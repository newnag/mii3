<?php 
/* 
Template Name : Home
*/
get_header(); ?>

<?php the_title();?>
<?php the_content();?>

<?php get_footer(); ?>